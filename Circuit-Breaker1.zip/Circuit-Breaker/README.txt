
http://localhost:8098/getStudentDetailsForSchool/xyzschool
http://localhost:9098/getSchoolDetails/xyzschool


add http://localhost:9098/hystrix.stream to Dashboard

Dashboard
http://localhost:9098/hystrix